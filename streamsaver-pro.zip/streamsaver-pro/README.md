# StreamSaver Pro

Discover streaming services you're already paying for through your carrier plans, credit cards, memberships, and student discounts.

## Deploy on Vercel

1. Push this folder to a GitHub repository
2. Go to vercel.com and import the repository
3. Vercel will auto-detect Vite and deploy

## Local Development

```bash
npm install
npm run dev
```
